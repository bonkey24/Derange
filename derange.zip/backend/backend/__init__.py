# Django project config package
